# WebStrike

This extension disables access to a website or collection of websites to help physical strikers get what they need.

## `strikes.json`

This is the list of websites for a current strike.