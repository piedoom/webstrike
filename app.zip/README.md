# WebStrike for Chrome AND Firefox

This extension disables access to a website or collection of websites to help physical strikers get what they need.

# Installing

[Try here](https://chrome.google.com/webstore/detail/gncbiclggjkgcnecfcfpdclkdojpjajj).  If it's not up yet, try [installing the old fashioned way](https://stackoverflow.com/questions/24577024/install-chrome-extension-not-in-the-store).  Download this repository as a `zip`, extract it, and then select the folder when installing according to the linked guide.

## `strikes.json`

This is the list of websites for a strike.  It'd be great to simply query GitHub in the future, but for now the extension can only be updated via the chrome store / manually editing and installing.

## Why is your code so awful?
Because JavaScript is the worst thing in the entire world, and I dread writing every minute of it.  Until we get some webasm stuff going for extensions, I will always hate every line of the terrible, terrible language.  If you see some parts that you'd like to clean up, go ahead and torture yourself.  By contributing you legally agree that JavaScript is the worst language on earth, and that you hated writing it.
